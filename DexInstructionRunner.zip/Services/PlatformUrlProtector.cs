using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace DexInstructionRunner.Services
{
    /// <summary>
    /// Protects/deprotects platform URLs for storage in appsettings.json.
    /// Windows: DPAPI (CurrentUser)
    /// macOS/Linux: AES-GCM with a per-install key stored under LocalApplicationData.
    /// </summary>
    public static class PlatformUrlProtector
    {
        public const string Prefix = "enc:";

        public static bool IsProtectedString(string? value)
            => !string.IsNullOrWhiteSpace(value) && value.StartsWith(Prefix, StringComparison.OrdinalIgnoreCase);

        public static string ProtectToPrefixedString(string plaintext)
        {
            plaintext ??= string.Empty;
            var trimmed = plaintext.Trim();
            if (trimmed.Length == 0)
                return Prefix;

            var bytes = Encoding.UTF8.GetBytes(trimmed);
            var protectedBytes = Protect(bytes);
            return Prefix + Convert.ToBase64String(protectedBytes);
        }

        public static string UnprotectPrefixedStringToPlaintext(string? protectedValue)
        {
            if (string.IsNullOrWhiteSpace(protectedValue))
                return string.Empty;

            if (!IsProtectedString(protectedValue))
                return protectedValue.Trim();

            var b64 = protectedValue.Substring(Prefix.Length);
            if (string.IsNullOrWhiteSpace(b64))
                return string.Empty;

            byte[] data;
            try
            {
                data = Convert.FromBase64String(b64);
            }
            catch
            {
                return string.Empty;
            }

            try
            {
                var unprotected = Unprotect(data);
                return Encoding.UTF8.GetString(unprotected).Trim();
            }
            catch
            {
                return string.Empty;
            }
        }

        private static byte[] Protect(byte[] plaintext)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                return ProtectedData.Protect(plaintext, null, DataProtectionScope.CurrentUser);
            }

            // AES-GCM: [12-byte nonce][16-byte tag][ciphertext]
            var key = GetOrCreateInstallKey();
            var nonce = RandomNumberGenerator.GetBytes(12);
            var ciphertext = new byte[plaintext.Length];
            var tag = new byte[16];

            using (var aes = new AesGcm(key))
            {
                aes.Encrypt(nonce, plaintext, ciphertext, tag);
            }

            var output = new byte[nonce.Length + tag.Length + ciphertext.Length];
            Buffer.BlockCopy(nonce, 0, output, 0, nonce.Length);
            Buffer.BlockCopy(tag, 0, output, nonce.Length, tag.Length);
            Buffer.BlockCopy(ciphertext, 0, output, nonce.Length + tag.Length, ciphertext.Length);
            return output;
        }

        private static byte[] Unprotect(byte[] protectedBytes)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                return ProtectedData.Unprotect(protectedBytes, null, DataProtectionScope.CurrentUser);
            }

            if (protectedBytes == null || protectedBytes.Length < (12 + 16))
                throw new CryptographicException("Invalid protected payload.");

            var key = GetOrCreateInstallKey();
            var nonce = new byte[12];
            var tag = new byte[16];
            var ciphertext = new byte[protectedBytes.Length - nonce.Length - tag.Length];

            Buffer.BlockCopy(protectedBytes, 0, nonce, 0, nonce.Length);
            Buffer.BlockCopy(protectedBytes, nonce.Length, tag, 0, tag.Length);
            Buffer.BlockCopy(protectedBytes, nonce.Length + tag.Length, ciphertext, 0, ciphertext.Length);

            var plaintext = new byte[ciphertext.Length];
            using (var aes = new AesGcm(key))
            {
                aes.Decrypt(nonce, ciphertext, tag, plaintext);
            }
            return plaintext;
        }

        private static byte[] GetOrCreateInstallKey()
        {
            // A simple per-install key store.
            // Note: user requested we don't migrate legacy entries yet; this only affects new encrypted values.
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DexInstructionRunner");
            Directory.CreateDirectory(dir);
            var path = Path.Combine(dir, "platformurl.key");

            if (File.Exists(path))
            {
                var existing = File.ReadAllBytes(path);
                if (existing.Length == 32)
                    return existing;
            }

            var key = RandomNumberGenerator.GetBytes(32);
            File.WriteAllBytes(path, key);
            return key;
        }
    }
}
