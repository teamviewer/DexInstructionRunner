﻿using System.Collections.Generic;

namespace DexInstructionRunner.Models
{
    public class AggregationDefinition
    {
        public List<string> Schema { get; set; } = new();
    }
}
